import { useMemo, useState, type FormEvent, type ReactNode } from 'react'
import {
  BarChart3,
  Bell,
  Boxes,
  Check,
  ChevronDown,
  CircleDollarSign,
  ClipboardList,
  Droplets,
  Edit3,
  Eye,
  Gift,
  LockKeyhole,
  LogIn,
  LogOut,
  Mail,
  Minus,
  PackagePlus,
  Plus,
  Printer,
  ReceiptText,
  Search,
  ShieldCheck,
  ShoppingCart,
  SlidersHorizontal,
  Sparkles,
  TrendingUp,
  UserRound,
  Users,
  X,
} from 'lucide-react'

type Page = 'inventory' | 'loyalty' | 'customers' | 'pos' | 'reports' | 'receipts'
type Role = 'admin' | 'cashier'
type Product = {
  id: number
  name: string
  sku: string
  category: string
  price: number
  stock: number
  minimum: number
  active: boolean
}
type Customer = {
  id: string
  name: string
  contact: string
  purchases: number
  spent: number
}

const initialProducts: Product[] = [
  { id: 1, name: '5-Gallon Water Refill', sku: 'WR-5GAL', category: 'Water Refill', price: 30, stock: 100, minimum: 20, active: true },
  { id: 2, name: '3-Gallon Water Refill', sku: 'WR-3GAL', category: 'Water Refill', price: 20, stock: 50, minimum: 15, active: true },
  { id: 3, name: 'Empty 5-Gallon Container', sku: 'CN-5GAL', category: 'Container', price: 150, stock: 8, minimum: 10, active: true },
  { id: 4, name: 'Bottled Water', sku: 'BW-500ML', category: 'Bottled Products', price: 15, stock: 80, minimum: 24, active: true },
  { id: 5, name: 'Water Dispenser Pump', sku: 'AC-PUMP', category: 'Accessories', price: 220, stock: 0, minimum: 5, active: false },
]

const initialCustomers: Customer[] = [
  { id: 'CUS-1048', name: 'Maria Santos', contact: '0917 234 1802', purchases: 31, spent: 8120 },
  { id: 'CUS-1092', name: 'Daniel Reyes', contact: '0998 440 1277', purchases: 16, spent: 4685 },
  { id: 'CUS-1124', name: 'Ana Dela Cruz', contact: '0920 812 9410', purchases: 7, spent: 1940 },
  { id: 'CUS-1156', name: 'Ramon Garcia', contact: '0916 334 9012', purchases: 3, spent: 760 },
]

const nav: { id: Page; label: string; icon: typeof Boxes; roles: Role[] }[] = [
  { id: 'inventory', label: 'Inventory', icon: Boxes, roles: ['admin'] },
  { id: 'pos', label: 'Point of sale', icon: ShoppingCart, roles: ['cashier'] },
  { id: 'customers', label: 'Customers', icon: Users, roles: ['admin', 'cashier'] },
  { id: 'loyalty', label: 'Loyalty program', icon: Gift, roles: ['admin'] },
  { id: 'reports', label: 'Sales reports', icon: BarChart3, roles: ['admin'] },
  { id: 'receipts', label: 'Receipt history', icon: ReceiptText, roles: ['admin', 'cashier'] },
]

const money = (value: number) =>
  new Intl.NumberFormat('en-PH', { style: 'currency', currency: 'PHP' }).format(value)

function levelFor(purchases: number) {
  if (purchases >= 25) return { name: 'Gold', discount: 10, className: 'gold' }
  if (purchases >= 10) return { name: 'Silver', discount: 5, className: 'silver' }
  return { name: 'Regular', discount: 0, className: 'regular' }
}

function Modal({ title, subtitle, children, onClose }: { title: string; subtitle: string; children: ReactNode; onClose: () => void }) {
  return (
    <div className="modal-backdrop" onMouseDown={onClose}>
      <section className="modal" onMouseDown={(event) => event.stopPropagation()}>
        <div className="modal-head">
          <div>
            <h2>{title}</h2>
            <p>{subtitle}</p>
          </div>
          <button className="icon-button" onClick={onClose} aria-label="Close modal"><X size={20} /></button>
        </div>
        {children}
      </section>
    </div>
  )
}

function App() {
  const [role, setRole] = useState<Role | null>(null)
  const [page, setPage] = useState<Page>('inventory')
  const [products, setProducts] = useState(initialProducts)
  const [customerList, setCustomerList] = useState(initialCustomers)
  const [query, setQuery] = useState('')
  const [status, setStatus] = useState('All products')
  const [modal, setModal] = useState<'add' | 'restock' | 'edit' | 'customer' | null>(null)
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null)
  const [toast, setToast] = useState('')

  const notify = (message: string) => {
    setToast(message)
    window.setTimeout(() => setToast(''), 2400)
  }

  const filteredProducts = products.filter((product) => {
    const matchesSearch = `${product.name} ${product.sku} ${product.category}`.toLowerCase().includes(query.toLowerCase())
    const matchesStatus =
      status === 'All products' ||
      (status === 'Active' && product.active) ||
      (status === 'Inactive' && !product.active) ||
      (status === 'Low stock' && product.stock <= product.minimum)
    return matchesSearch && matchesStatus
  })

  const openProduct = (type: 'restock' | 'edit', product: Product) => {
    setSelectedProduct(product)
    setModal(type)
  }

  const toggleProduct = (id: number) => {
    setProducts((items) => items.map((item) => item.id === id ? { ...item, active: !item.active } : item))
    notify('Product availability updated')
  }

  const signIn = (nextRole: Role) => {
    setRole(nextRole)
    setPage(nextRole === 'admin' ? 'inventory' : 'pos')
  }

  const signOut = () => {
    setRole(null)
    setPage('inventory')
  }

  if (!role) return <LoginScreen onSignIn={signIn} />

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand">
          <div className="brand-mark"><Droplets size={22} strokeWidth={2.4} /></div>
          <div><strong>AquaFlow</strong><span>Water Station</span></div>
        </div>
        <nav>
          <div className="nav-label">{role === 'admin' ? 'Admin workspace' : 'Cashier workspace'}</div>
          {nav.filter((item) => item.roles.includes(role)).map((item) => {
            const Icon = item.icon
            return (
              <button key={item.id} className={`nav-item ${page === item.id ? 'active' : ''}`} onClick={() => setPage(item.id)}>
                <Icon size={19} /> {item.label}
                {item.id === 'inventory' && <span className="nav-badge">2</span>}
              </button>
            )
          })}
        </nav>
        <div className="profile">
          <div className="avatar">{role === 'admin' ? 'AS' : 'JS'}</div>
          <div><strong>{role === 'admin' ? 'Alex Santos' : 'Jamie Santos'}</strong><span>{role === 'admin' ? 'Administrator' : 'Cashier · Shift active'}</span></div>
          <button aria-label="Log out" title="Log out" onClick={signOut}><LogOut size={17} /></button>
        </div>
      </aside>

      <main className="main">
        <header className="topbar">
          <div className="mobile-brand"><Droplets size={20} /> AquaFlow</div>
          <div className="topbar-right">
            <span className={`role-label ${role}`}><ShieldCheck size={14} /> {role === 'admin' ? 'Admin portal' : 'Cashier portal'}</span>
            <span className="live-indicator"><i /> Station open</span>
            <button className="icon-button notification" aria-label="Notifications" onClick={() => notify('3 inventory alerts need review')}><Bell size={20} /><b>3</b></button>
            <div className="top-avatar">{role === 'admin' ? 'AS' : 'JS'}</div>
            <button className="mobile-logout" onClick={signOut}><LogOut size={16} /> Log out</button>
          </div>
        </header>

        {page === 'inventory' && (
          <InventoryPage
            products={products}
            filteredProducts={filteredProducts}
            query={query}
            setQuery={setQuery}
            status={status}
            setStatus={setStatus}
            onAdd={() => setModal('add')}
            onEdit={(product) => openProduct('edit', product)}
            onRestock={(product) => openProduct('restock', product)}
            onToggle={toggleProduct}
          />
        )}
        {page === 'loyalty' && <LoyaltyPage notify={notify} />}
        {page === 'customers' && <CustomersPage customers={customerList} role={role} onRegister={() => setModal('customer')} />}
        {page === 'pos' && <PosPage
          notify={notify}
          customers={customerList}
          onComplete={(customerId, total) => {
            setCustomerList((items) => items.map((customer) => customer.id === customerId
              ? { ...customer, purchases: customer.purchases + 1, spent: customer.spent + total }
              : customer))
          }}
        />}
        {page === 'reports' && <ReportsPage />}
        {page === 'receipts' && <ReceiptsPage />}
      </main>

      {modal === 'add' && (
        <ProductFormModal
          onClose={() => setModal(null)}
          onSave={(product) => {
            setProducts((items) => [...items, { ...product, id: Date.now(), active: true }])
            setModal(null)
            notify('New product added to inventory')
          }}
        />
      )}
      {modal === 'edit' && selectedProduct && (
        <ProductFormModal
          product={selectedProduct}
          onClose={() => setModal(null)}
          onSave={(product) => {
            setProducts((items) => items.map((item) => item.id === selectedProduct.id ? { ...item, ...product } : item))
            setModal(null)
            notify('Product details saved')
          }}
        />
      )}
      {modal === 'restock' && selectedProduct && (
        <RestockModal
          product={selectedProduct}
          onClose={() => setModal(null)}
          onSave={(quantity) => {
            setProducts((items) => items.map((item) => item.id === selectedProduct.id ? { ...item, stock: item.stock + quantity } : item))
            setModal(null)
            notify(`${quantity} units added to stock`)
          }}
        />
      )}
      {modal === 'customer' && (
        <CustomerFormModal
          onClose={() => setModal(null)}
          onSave={(customer) => {
            setCustomerList((items) => [...items, customer])
            setModal(null)
            notify('Customer registered successfully')
          }}
        />
      )}
      {toast && <div className="toast"><span><Check size={16} /></span>{toast}</div>}
    </div>
  )
}

function LoginScreen({ onSignIn }: { onSignIn: (role: Role) => void }) {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const submitLogin = (event: FormEvent) => {
    event.preventDefault()
    const normalizedEmail = email.trim().toLowerCase()
    if (normalizedEmail === 'admin@aquaflow.ph' && password === 'admin123') {
      onSignIn('admin')
      return
    }
    if (normalizedEmail === 'cashier@aquaflow.ph' && password === 'cashier123') {
      onSignIn('cashier')
      return
    }
    setError('The email or password you entered is incorrect.')
  }
  return (
    <div className="login-page">
      <section className="login-story">
        <div className="login-brand"><div className="brand-mark"><Droplets size={24} /></div><div><strong>AquaFlow</strong><span>Water Station Management</span></div></div>
        <div className="story-content">
          <span className="story-kicker">One station. One clear flow.</span>
          <h1>Keep every refill, reward, and transaction moving.</h1>
          <p>A focused workspace for managing inventory and serving customers—built around the responsibilities of your team.</p>
          <div className="access-preview">
            <div><span><ShieldCheck size={17} /></span><div><strong>Administrator</strong><p>Products, inventory, loyalty rules, customers, reports, and POS.</p></div></div>
            <div><span><ShoppingCart size={17} /></span><div><strong>Cashier</strong><p>POS checkout, customer registration, automatic discounts, and receipts.</p></div></div>
          </div>
        </div>
        <p className="story-footer">AquaFlow Station · Secure staff access</p>
      </section>
      <main className="login-main">
        <div className="login-card">
          <div className="login-heading"><span>Secure staff access</span><h2>Sign in to AquaFlow</h2><p>Enter the credentials assigned to your staff account.</p></div>
          <form className="login-form" onSubmit={submitLogin}>
            <label><span>Email address</span><div className={error ? 'input-error' : ''}><Mail size={17} /><input autoFocus required type="email" autoComplete="username" value={email} onChange={(event) => { setEmail(event.target.value); setError('') }} placeholder="name@aquaflow.ph" /></div></label>
            <label><span>Password <em>Contact admin for access help</em></span><div className={error ? 'input-error' : ''}><LockKeyhole size={17} /><input required type="password" autoComplete="current-password" value={password} onChange={(event) => { setPassword(event.target.value); setError('') }} placeholder="Enter your password" /></div></label>
            {error && <div className="login-error" role="alert"><X size={15} /><span><strong>Unable to sign in</strong>{error}</span></div>}
            <button className="login-button" type="submit"><LogIn size={18} /> Sign in</button>
          </form>
          <div className="secure-note"><ShieldCheck size={16} /><p><strong>Your access is assigned automatically</strong><span>Administrators and cashiers are directed to their permitted workspace based on their account.</span></p></div>
          <div className="demo-accounts">
            <div className="demo-accounts-head"><span>Demo accounts</span><small>Use either account to explore its workspace</small></div>
            <div className="demo-account-row">
              <span className="demo-role admin"><ShieldCheck size={15} /></span>
              <div><strong>Administrator</strong><span>admin@aquaflow.ph</span></div>
              <div><small>Password</small><code>admin123</code></div>
            </div>
            <div className="demo-account-row">
              <span className="demo-role cashier"><ShoppingCart size={15} /></span>
              <div><strong>Cashier</strong><span>cashier@aquaflow.ph</span></div>
              <div><small>Password</small><code>cashier123</code></div>
            </div>
          </div>
        </div>
        <p className="login-help">Need access? Contact your station administrator.</p>
      </main>
    </div>
  )
}

function InventoryPage({
  products, filteredProducts, query, setQuery, status, setStatus, onAdd, onEdit, onRestock, onToggle,
}: {
  products: Product[]; filteredProducts: Product[]; query: string; setQuery: (value: string) => void
  status: string; setStatus: (value: string) => void; onAdd: () => void
  onEdit: (product: Product) => void; onRestock: (product: Product) => void; onToggle: (id: number) => void
}) {
  const lowStock = products.filter((product) => product.stock <= product.minimum).length
  const inventoryValue = products.reduce((sum, product) => sum + product.price * product.stock, 0)
  const exportProducts = () => {
    const rows = [
      ['Product', 'SKU', 'Category', 'Price', 'Stock', 'Minimum stock', 'Status'],
      ...products.map((product) => [product.name, product.sku, product.category, product.price, product.stock, product.minimum, product.active ? 'Active' : 'Inactive']),
    ]
    const csv = rows.map((row) => row.map((cell) => `"${String(cell).replaceAll('"', '""')}"`).join(',')).join('\n')
    const url = URL.createObjectURL(new Blob([csv], { type: 'text/csv' }))
    const link = document.createElement('a')
    link.href = url
    link.download = 'aquaflow-inventory.csv'
    link.click()
    URL.revokeObjectURL(url)
  }
  return (
    <div className="page">
      <div className="page-heading">
        <div><span className="eyebrow">Product management</span><h1>Inventory</h1><p>Manage your product catalog, pricing, and stock levels.</p></div>
        <button className="primary-button" onClick={onAdd}><Plus size={18} /> Add new product</button>
      </div>
      <div className="stat-grid">
        <Stat icon={<Boxes />} label="Total products" value={String(products.length)} detail={`${products.filter((p) => p.active).length} currently active`} tone="blue" />
        <Stat icon={<PackagePlus />} label="Units in stock" value={String(products.reduce((a, b) => a + b.stock, 0))} detail="Across all products" tone="teal" />
        <Stat icon={<TrendingUp />} label="Inventory value" value={money(inventoryValue)} detail="At current selling price" tone="violet" />
        <Stat icon={<Bell />} label="Stock alerts" value={String(lowStock)} detail="Needs your attention" tone="amber" />
      </div>
      {lowStock > 0 && (
        <div className="alert-banner">
          <div className="alert-icon"><Bell size={19} /></div>
          <div><strong>{lowStock} products need attention</strong><span>Some items are at or below their minimum stock level.</span></div>
          <button onClick={() => setStatus('Low stock')}>View low stock</button>
        </div>
      )}
      <section className="panel">
        <div className="panel-head">
          <div><h2>Product catalog</h2><p>{filteredProducts.length} of {products.length} products</p></div>
          <button className="secondary-button" onClick={exportProducts}><SlidersHorizontal size={17} /> Export list</button>
        </div>
        <div className="toolbar">
          <label className="search-field"><Search size={18} /><input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search products, SKU, or category..." /></label>
          <label className="select-field"><select value={status} onChange={(e) => setStatus(e.target.value)}>
            <option>All products</option><option>Active</option><option>Inactive</option><option>Low stock</option>
          </select><ChevronDown size={17} /></label>
        </div>
        <div className="table-wrap">
          <table>
            <thead><tr><th>Product</th><th>Category</th><th>Price</th><th>Stock level</th><th>Status</th><th /></tr></thead>
            <tbody>
              {filteredProducts.map((product) => {
                const isLow = product.stock <= product.minimum
                return (
                  <tr key={product.id}>
                    <td><div className="product-cell"><div className={`product-icon category-${product.category.toLowerCase().replace(' ', '-')}`}><Droplets size={19} /></div><div><strong>{product.name}</strong><span>{product.sku}</span></div></div></td>
                    <td><span className="category-pill">{product.category}</span></td>
                    <td><strong>{money(product.price)}</strong></td>
                    <td>
                      <div className="stock-cell"><div><strong className={isLow ? 'stock-low' : ''}>{product.stock} units</strong>{isLow && <span className="low-label">Low stock</span>}</div><span>Min. {product.minimum}</span></div>
                    </td>
                    <td><button className={`status-toggle ${product.active ? 'on' : ''}`} onClick={() => onToggle(product.id)}><i /><span>{product.active ? 'Active' : 'Inactive'}</span></button></td>
                    <td><div className="row-actions"><button onClick={() => onRestock(product)} title="Restock"><PackagePlus size={17} /></button><button onClick={() => onEdit(product)} title="Edit"><Edit3 size={17} /></button></div></td>
                  </tr>
                )
              })}
            </tbody>
          </table>
          {!filteredProducts.length && <div className="empty-state"><Search size={26} /><strong>No products found</strong><span>Try a different search or filter.</span></div>}
        </div>
        <div className="panel-foot"><span>Showing {filteredProducts.length} products</span><div><button disabled>Previous</button><button className="current">1</button><button disabled>Next</button></div></div>
      </section>
    </div>
  )
}

function Stat({ icon, label, value, detail, tone }: { icon: ReactNode; label: string; value: string; detail: string; tone: string }) {
  return <article className="stat-card"><div className={`stat-icon ${tone}`}>{icon}</div><div><span>{label}</span><strong>{value}</strong><small>{detail}</small></div></article>
}

function ProductFormModal({ product, onClose, onSave }: { product?: Product; onClose: () => void; onSave: (product: Omit<Product, 'id' | 'active'>) => void }) {
  const [name, setName] = useState(product?.name ?? '')
  const [category, setCategory] = useState(product?.category ?? 'Water Refill')
  const [price, setPrice] = useState(product?.price ?? 30)
  const [stock, setStock] = useState(product?.stock ?? 0)
  const [minimum, setMinimum] = useState(product?.minimum ?? 10)
  const [description, setDescription] = useState('')
  const submit = (event: FormEvent) => {
    event.preventDefault()
    onSave({ name, category, price, stock, minimum, sku: product?.sku ?? `PR-${String(Date.now()).slice(-4)}` })
  }
  return (
    <Modal title={product ? 'Edit product' : 'Add new product'} subtitle={product ? 'Update product information and pricing.' : 'Add a new item to your station inventory.'} onClose={onClose}>
      <form onSubmit={submit} className="form">
        <label className="field full"><span>Product name</span><input required value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. 5-Gallon Water Refill" /></label>
        <label className="field full"><span>Description <em>Optional</em></span><textarea value={description} onChange={(e) => setDescription(e.target.value)} placeholder="Short description for staff and receipts" rows={3} /></label>
        <label className="field full"><span>Category</span><div className="select-control"><select value={category} onChange={(e) => setCategory(e.target.value)}><option>Water Refill</option><option>Container</option><option>Bottled Products</option><option>Accessories</option></select><ChevronDown size={17} /></div></label>
        <label className="field"><span>Selling price</span><div className="money-input"><b>₱</b><input required min="0" type="number" value={price} onChange={(e) => setPrice(Number(e.target.value))} /></div></label>
        <label className="field"><span>Initial stock</span><input required min="0" type="number" value={stock} onChange={(e) => setStock(Number(e.target.value))} /></label>
        <label className="field full"><span>Minimum stock level</span><input required min="0" type="number" value={minimum} onChange={(e) => setMinimum(Number(e.target.value))} /><small>You’ll receive an alert when stock reaches this amount.</small></label>
        <div className="modal-actions"><button type="button" className="secondary-button" onClick={onClose}>Cancel</button><button className="primary-button" type="submit"><Check size={17} /> {product ? 'Save changes' : 'Save product'}</button></div>
      </form>
    </Modal>
  )
}

function RestockModal({ product, onClose, onSave }: { product: Product; onClose: () => void; onSave: (quantity: number) => void }) {
  const [quantity, setQuantity] = useState(25)
  return (
    <Modal title="Restock product" subtitle="Record newly received supplies in inventory." onClose={onClose}>
      <div className="restock-product"><div className="product-icon"><Droplets size={20} /></div><div><strong>{product.name}</strong><span>{product.stock} units currently available</span></div></div>
      <form className="form" onSubmit={(e) => { e.preventDefault(); onSave(quantity) }}>
        <label className="field full"><span>Quantity received</span><input autoFocus type="number" min="1" value={quantity} onChange={(e) => setQuantity(Number(e.target.value))} /><small>New stock level: <strong>{product.stock + quantity} units</strong></small></label>
        <label className="field full"><span>Stock note <em>Optional</em></span><input placeholder="e.g. Weekly supplier delivery" /></label>
        <div className="info-note"><ClipboardList size={18} /><span>This stock change will be added to the inventory activity log.</span></div>
        <div className="modal-actions"><button type="button" className="secondary-button" onClick={onClose}>Cancel</button><button className="primary-button" type="submit"><PackagePlus size={17} /> Add to stock</button></div>
      </form>
    </Modal>
  )
}

function CustomerFormModal({ onClose, onSave }: { onClose: () => void; onSave: (customer: Customer) => void }) {
  const [name, setName] = useState('')
  const [contact, setContact] = useState('')
  const submit = (event: FormEvent) => {
    event.preventDefault()
    onSave({
      id: `CUS-${String(Date.now()).slice(-4)}`,
      name: name.trim(),
      contact: contact.trim(),
      purchases: 0,
      spent: 0,
    })
  }
  return (
    <Modal title="Register customer" subtitle="Create a customer profile for purchase and loyalty tracking." onClose={onClose}>
      <form className="form" onSubmit={submit}>
        <label className="field full"><span>Customer name</span><input autoFocus required value={name} onChange={(event) => setName(event.target.value)} placeholder="Enter full name" /></label>
        <label className="field full"><span>Contact number</span><input required value={contact} onChange={(event) => setContact(event.target.value)} placeholder="e.g. 0917 123 4567" /></label>
        <div className="info-note"><Gift size={18} /><span>New customers start at the Regular level with zero completed purchases.</span></div>
        <div className="modal-actions"><button type="button" className="secondary-button" onClick={onClose}>Cancel</button><button className="primary-button" type="submit"><Check size={17} /> Register customer</button></div>
      </form>
    </Modal>
  )
}

function LoyaltyPage({ notify }: { notify: (message: string) => void }) {
  const [enabled, setEnabled] = useState(true)
  const [silver, setSilver] = useState(10)
  const [gold, setGold] = useState(25)
  const [silverDiscount, setSilverDiscount] = useState(5)
  const [goldDiscount, setGoldDiscount] = useState(10)
  return (
    <div className="page">
      <div className="page-heading"><div><span className="eyebrow">Customer rewards</span><h1>Loyalty program</h1><p>Configure automatic discounts for your returning customers.</p></div><button className="primary-button" onClick={() => notify('Loyalty settings saved')}><Check size={18} /> Save changes</button></div>
      <div className="loyalty-banner">
        <div className="loyalty-art"><Gift size={34} /><Sparkles size={17} /></div>
        <div><span>Automatic rewards</span><h2>Turn every refill into a reason to return.</h2><p>Customers move up automatically after completed purchases. Canceled and voided transactions never count.</p></div>
        <label className="master-switch"><input type="checkbox" checked={enabled} onChange={() => setEnabled(!enabled)} /><i /><span>{enabled ? 'Program active' : 'Program paused'}</span></label>
      </div>
      <div className="content-grid">
        <section className="panel">
          <div className="panel-head"><div><h2>Loyalty levels</h2><p>Set purchase requirements and discounts.</p></div></div>
          <div className="tier-list">
            <Tier icon={<UserRound />} name="Regular customer" color="regular" requirement="Default level" discount={0} locked />
            <Tier icon={<Sparkles />} name="Silver member" color="silver" requirementControl={<><input value={silver} onChange={(e) => setSilver(Number(e.target.value))} type="number" /> completed purchases</>} discount={silverDiscount} onDiscountChange={setSilverDiscount} />
            <Tier icon={<Gift />} name="Gold member" color="gold" requirementControl={<><input value={gold} onChange={(e) => setGold(Number(e.target.value))} type="number" /> completed purchases</>} discount={goldDiscount} onDiscountChange={setGoldDiscount} />
          </div>
        </section>
        <aside className="side-stack">
          <section className="panel compact">
            <div className="panel-head"><div><h2>Program snapshot</h2><p>Current customer distribution</p></div></div>
            <div className="distribution"><div><span className="dot gold" /><b>Gold</b><em>48</em></div><div><span className="dot silver" /><b>Silver</b><em>86</em></div><div><span className="dot regular" /><b>Regular</b><em>142</em></div></div>
            <div className="member-bar"><i /><i /><i /></div>
            <small>276 registered customers</small>
          </section>
          <section className="panel compact discount-card"><div className="discount-icon"><CircleDollarSign size={22} /></div><span>This month</span><strong>₱3,840.00</strong><p>Total loyalty discounts granted across 124 completed transactions.</p></section>
        </aside>
      </div>
    </div>
  )
}

function Tier({ icon, name, color, requirement, requirementControl, discount, onDiscountChange, locked }: { icon: ReactNode; name: string; color: string; requirement?: string; requirementControl?: ReactNode; discount: number; onDiscountChange?: (value: number) => void; locked?: boolean }) {
  return <div className="tier-row"><div className={`tier-icon ${color}`}>{icon}</div><div className="tier-name"><strong>{name}</strong><span>{locked ? 'Base membership' : 'Automatic upgrade'}</span></div><div className="tier-rule"><label>Requirement</label><div>{requirement ?? requirementControl}</div></div><div className="tier-rule discount-input"><label>Discount</label><div><input value={discount} min="0" max="100" type="number" readOnly={locked} onChange={(event) => onDiscountChange?.(Number(event.target.value))} />%</div></div></div>
}

function CustomersPage({ customers, role, onRegister }: { customers: Customer[]; role: Role; onRegister: () => void }) {
  const [search, setSearch] = useState('')
  const [selected, setSelected] = useState<Customer | null>(null)
  const filteredCustomers = customers.filter((customer) =>
    `${customer.name} ${customer.id} ${customer.contact}`.toLowerCase().includes(search.toLowerCase()),
  )
  return (
    <div className="page">
      <div className="page-heading"><div><span className="eyebrow">Customer management</span><h1>Customers</h1><p>View loyalty levels and completed purchase history.</p></div>{role === 'admin' && <button className="primary-button" onClick={onRegister}><Plus size={18} /> Register customer</button>}</div>
      <div className="stat-grid three"><Stat icon={<Users />} label="Registered customers" value="276" detail="+18 this month" tone="blue" /><Stat icon={<Gift />} label="Loyal members" value="134" detail="Silver and Gold" tone="violet" /><Stat icon={<TrendingUp />} label="Repeat purchase rate" value="68%" detail="+4.2% from last month" tone="teal" /></div>
      <section className="panel">
        <div className="panel-head"><div><h2>Customer directory</h2><p>Search and review customer activity.</p></div></div>
        <div className="toolbar"><label className="search-field"><Search size={18} /><input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Search by name, ID, or contact number..." /></label></div>
        <div className="table-wrap"><table><thead><tr><th>Customer</th><th>Contact number</th><th>Loyalty level</th><th>Completed purchases</th><th>Total spent</th><th /></tr></thead>
          <tbody>{filteredCustomers.map((customer) => { const level = levelFor(customer.purchases); return <tr key={customer.id}><td><div className="customer-cell"><div>{customer.name.split(' ').map((n) => n[0]).join('').slice(0, 2)}</div><span><strong>{customer.name}</strong><small>{customer.id}</small></span></div></td><td>{customer.contact}</td><td><span className={`level-pill ${level.className}`}>{level.name} {level.discount > 0 && `· ${level.discount}%`}</span></td><td><strong>{customer.purchases}</strong></td><td><strong>{money(customer.spent)}</strong></td><td><button className="icon-button" title="View customer" onClick={() => setSelected(customer)}><Eye size={18} /></button></td></tr> })}</tbody>
        </table></div>
      </section>
      {selected && <CustomerDetailsModal customer={selected} onClose={() => setSelected(null)} />}
    </div>
  )
}

function CustomerDetailsModal({ customer, onClose }: { customer: Customer; onClose: () => void }) {
  const level = levelFor(customer.purchases)
  return (
    <Modal title={customer.name} subtitle={`${customer.id} · Customer profile`} onClose={onClose}>
      <div className="customer-detail">
        <div><span>Contact number</span><strong>{customer.contact}</strong></div>
        <div><span>Loyalty level</span><strong className={level.className}>{level.name} · {level.discount}% discount</strong></div>
        <div><span>Completed purchases</span><strong>{customer.purchases}</strong></div>
        <div><span>Total amount spent</span><strong>{money(customer.spent)}</strong></div>
      </div>
      <div className="modal-footer"><button className="primary-button" onClick={onClose}>Done</button></div>
    </Modal>
  )
}

function PosPage({ notify, customers, onComplete }: { notify: (message: string) => void; customers: Customer[]; onComplete: (customerId: string, total: number) => void }) {
  const [selectedCustomer, setSelectedCustomer] = useState(customers[0])
  const [quantities, setQuantities] = useState<Record<number, number>>({ 1: 2, 4: 3 })
  const saleProducts = initialProducts.filter((product) => quantities[product.id])
  const subtotal = saleProducts.reduce((sum, product) => sum + product.price * quantities[product.id], 0)
  const level = levelFor(selectedCustomer.purchases)
  const discount = subtotal * level.discount / 100
  const total = subtotal - discount
  const updateQty = (id: number, amount: number) => setQuantities((current) => ({ ...current, [id]: Math.max(0, (current[id] ?? 0) + amount) }))
  const completeSale = () => {
    if (!subtotal) return
    onComplete(selectedCustomer.id, total)
    setQuantities({})
    notify('Sale completed, customer history updated, and receipt prepared')
  }
  return (
    <div className="page">
      <div className="page-heading"><div><span className="eyebrow">Cashier workspace</span><h1>New sale</h1><p>Order #AF-2025-0187 · Cashier: Jamie Santos · Shift active</p></div><button className="secondary-button" onClick={() => setQuantities({})}><X size={17} /> Clear order</button></div>
      <div className="pos-grid">
        <section className="panel product-picker">
          <div className="toolbar"><label className="search-field"><Search size={18} /><input placeholder="Search products..." /></label></div>
          <div className="product-grid">{initialProducts.filter((p) => p.active).map((product) => <button key={product.id} className="sale-product" onClick={() => updateQty(product.id, 1)}><div className="sale-product-icon"><Droplets size={22} /></div><span>{product.category}</span><strong>{product.name}</strong><div><b>{money(product.price)}</b><small>{product.stock} in stock</small></div></button>)}</div>
        </section>
        <aside className="checkout">
          <section className="panel compact">
            <div className="panel-head"><div><h2>Current order</h2><p>{saleProducts.length} product types</p></div><span className="order-status">Draft</span></div>
            <div className="cart-items">{saleProducts.map((product) => <div className="cart-item" key={product.id}><div><strong>{product.name}</strong><span>{money(product.price)} each</span></div><div className="quantity"><button onClick={() => updateQty(product.id, -1)}><Minus size={14} /></button><b>{quantities[product.id]}</b><button onClick={() => updateQty(product.id, 1)}><Plus size={14} /></button></div><strong>{money(product.price * quantities[product.id])}</strong></div>)}</div>
            <div className="customer-select"><label>Customer</label><div className="select-control"><select value={selectedCustomer.id} onChange={(e) => setSelectedCustomer(customers.find((c) => c.id === e.target.value) ?? customers[0])}>{customers.map((customer) => <option key={customer.id} value={customer.id}>{customer.name} · {customer.contact}</option>)}</select><ChevronDown size={17} /></div></div>
            <div className={`applied-discount ${level.discount ? '' : 'none'}`}><div><Gift size={18} /><span><strong>{level.name} member</strong><small>{level.discount ? `${level.discount}% loyalty discount automatically applied` : 'No loyalty discount for this level'}</small></span></div><b>{level.discount ? `−${money(discount)}` : '—'}</b></div>
            <div className="totals"><div><span>Subtotal</span><b>{money(subtotal)}</b></div><div className="discount-line"><span>Loyalty discount</span><b>−{money(discount)}</b></div><div className="grand-total"><span>Total amount due</span><b>{money(total)}</b></div></div>
            <button className="checkout-button" disabled={!subtotal} onClick={completeSale}><Check size={19} /> Complete transaction</button>
            <p className="checkout-note">Only completed transactions count toward loyalty status.</p>
          </section>
        </aside>
      </div>
    </div>
  )
}

function ReceiptsPage() {
  const [search, setSearch] = useState('')
  const [status, setStatus] = useState('All transactions')
  const receipts = [
    { id: 'AF-2025-0186', customer: 'Maria Santos', cashier: 'Jamie Santos', time: '10:42 AM', subtotal: 200, discount: 20, total: 180, status: 'Completed' },
    { id: 'AF-2025-0185', customer: 'Walk-in customer', cashier: 'Jamie Santos', time: '10:18 AM', subtotal: 150, discount: 0, total: 150, status: 'Completed' },
    { id: 'AF-2025-0184', customer: 'Daniel Reyes', cashier: 'Jamie Santos', time: '9:56 AM', subtotal: 250, discount: 12.5, total: 237.5, status: 'Completed' },
    { id: 'AF-2025-0183', customer: 'Ana Dela Cruz', cashier: 'Jamie Santos', time: '9:31 AM', subtotal: 90, discount: 0, total: 90, status: 'Voided' },
  ]
  const filteredReceipts = receipts.filter((receipt) => {
    const matchesSearch = `${receipt.id} ${receipt.customer} ${receipt.cashier}`.toLowerCase().includes(search.toLowerCase())
    return matchesSearch && (status === 'All transactions' || receipt.status === status)
  })
  return (
    <div className="page">
      <div className="page-heading"><div><span className="eyebrow">Cashier records</span><h1>Receipt history</h1><p>Review and reprint today’s completed transaction receipts.</p></div><button className="secondary-button" onClick={() => window.print()}><Printer size={17} /> Print end-of-shift report</button></div>
      <div className="stat-grid three"><Stat icon={<ReceiptText />} label="Completed today" value="42" detail="₱4,860.00 in sales" tone="blue" /><Stat icon={<Gift />} label="Discounted sales" value="11" detail="₱284.50 granted" tone="violet" /><Stat icon={<ClipboardList />} label="Voided transactions" value="2" detail="Excluded from loyalty" tone="amber" /></div>
      <section className="panel">
        <div className="panel-head"><div><h2>Today’s transactions</h2><p>June 18, 2025 · Cashier: Jamie Santos</p></div></div>
        <div className="toolbar"><label className="search-field"><Search size={18} /><input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Search receipt, customer, or cashier..." /></label><label className="select-field"><select value={status} onChange={(event) => setStatus(event.target.value)}><option>All transactions</option><option>Completed</option><option>Voided</option></select><ChevronDown size={17} /></label></div>
        <div className="table-wrap"><table><thead><tr><th>Receipt</th><th>Customer</th><th>Cashier</th><th>Subtotal</th><th>Discount</th><th>Total</th><th>Status</th><th /></tr></thead>
          <tbody>{filteredReceipts.map((receipt) => <tr key={receipt.id}><td><div className="receipt-id"><strong>{receipt.id}</strong><span>{receipt.time}</span></div></td><td><strong>{receipt.customer}</strong></td><td>{receipt.cashier}</td><td>{money(receipt.subtotal)}</td><td className={receipt.discount ? 'discount-amount' : ''}>{receipt.discount ? `−${money(receipt.discount)}` : '—'}</td><td><strong>{money(receipt.total)}</strong></td><td><span className={`transaction-status ${receipt.status.toLowerCase()}`}>{receipt.status}</span></td><td><button className="print-button" disabled={receipt.status === 'Voided'} onClick={() => window.print()}><Printer size={16} /> Reprint</button></td></tr>)}</tbody>
        </table></div>
        <div className="panel-foot"><span>Showing {filteredReceipts.length} transactions</span><span>Voided sales do not count toward customer loyalty.</span></div>
      </section>
    </div>
  )
}

function ReportsPage() {
  const bars = [48, 64, 43, 76, 58, 90, 72]
  return (
    <div className="page">
      <div className="page-heading"><div><span className="eyebrow">Business performance</span><h1>Sales reports</h1><p>Revenue, transactions, and discounts granted.</p></div><span className="date-range"><SlidersHorizontal size={17} /> Jun 1 – Jun 30</span></div>
      <div className="stat-grid"><Stat icon={<CircleDollarSign />} label="Gross sales" value="₱86,420" detail="+12.8% this month" tone="blue" /><Stat icon={<ShoppingCart />} label="Transactions" value="1,284" detail="₱67.30 average sale" tone="teal" /><Stat icon={<Gift />} label="Discounts granted" value="₱3,840" detail="4.4% of gross sales" tone="violet" /><Stat icon={<UserRound />} label="Repeat customers" value="68%" detail="+4.2% this month" tone="amber" /></div>
      <div className="report-grid">
        <section className="panel chart-panel"><div className="panel-head"><div><h2>Sales overview</h2><p>Revenue over the last 7 days</p></div><strong>₱21,640</strong></div><div className="chart">{bars.map((height, i) => <div key={i}><span style={{ height: `${height}%` }} /><small>{['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'][i]}</small></div>)}</div></section>
        <section className="panel compact"><div className="panel-head"><div><h2>Recent discounts</h2><p>Latest completed sales</p></div></div><div className="activity-list">{initialCustomers.slice(0, 3).map((customer, i) => { const level = levelFor(customer.purchases); return <div key={customer.id}><div className={`tier-icon ${level.className}`}><Gift size={16} /></div><span><strong>{customer.name}</strong><small>{level.name} · Cashier: Jamie</small></span><b>−{money([20, 12.5, 0][i])}</b></div> })}</div></section>
      </div>
    </div>
  )
}

export default App
